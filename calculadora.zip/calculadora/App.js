import React, { useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

export default function App() {
  const [display, setDisplay] = useState('');
  const [result, setResult] = useState('');

  const handlePress = (value) => {
    if (value === '=') {
      try {
        const res = eval(display);
        setResult(res.toString());
      } catch (error) {
        setResult('Erro');
      }
    } else if (value === 'C') {
      setDisplay('');
      setResult('');
    } else {
      setDisplay(display + value);
    }
  };

  const buttons = [
    ['C', '(', ')', '/'],
    ['7', '8', '9', '*'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '=', 'nada']
  ];

  return (
    <View style={styles.container}>
      <View style={styles.displayArea}>
        <Text style={styles.inputText}>{display}</Text>
        <Text style={styles.resultText}>{result}</Text>
      </View>
      
      <View style={styles.buttonsArea}>
        {buttons.map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((buttonValue) => (
              <TouchableOpacity
                key={buttonValue}
                style={[
                  styles.button, 
                  buttonValue === '=' ? styles.buttonEqual : {}
                ]}
                onPress={() => handlePress(buttonValue)}
              >
                <Text style={styles.buttonText}>{buttonValue}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
  },
  displayArea: {
    flex: 2,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    padding: 20,
  },
  inputText: {
    fontSize: 40,
    color: 'gray',
  },
  resultText: {
    fontSize: 50,
    color: 'green',
    fontWeight: 'bold',
  },
  buttonsArea: {
    flex: 3,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
  },
  button: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 1,
    backgroundColor: 'gray',
    borderRadius: 5,
  },
  buttonEqual: {
    backgroundColor: 'orange',
  },
  buttonText: {
    fontSize: 24,
    color: 'whyte',
  },
});

