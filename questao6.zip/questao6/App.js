import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';

const QUIZ = [
  {
    id: 1,
    pergunta: 'Qual é o planeta mais próximo do Sol?',
    opcoes: ['Vênus', 'Mercúrio', 'Terra', 'Marte'],
    respostaCerta: 1,
    imagem: 'https://static.escolakids.uol.com.br/2025/01/1-sol-visto-do-universo.jpg'
  },
  {
    id: 2,
    pergunta: 'Qual é o maior planeta do Sistema Solar?',
    opcoes: ['Saturno', 'Netuno', 'Júpiter', 'Urano'],
    respostaCerta: 2,
    imagem: 'https://conhecimentocientifico.r7.com/wp-content/uploads/2020/12/o-que-sao-planetas-definicao-tipos-e-sistema-solar.jpeg'
  },
  {
    id: 3,
    pergunta: 'Qual planeta é conhecido como "Planeta Vermelho"?',
    opcoes: ['Vênus', 'Marte', 'Júpiter', 'Saturno'],
    respostaCerta: 1,
    imagem: 'https://s1.static.brasilescola.uol.com.br/be/2021/11/planeta-marte.jpg'
  },
  {
    id: 4,
    pergunta: 'Qual é o planeta mais distante do Sol?',
    opcoes: ['Netuno', 'Urano', 'Saturno', 'Plutão'],
    respostaCerta: 0,
    imagem: 'https://chc.org.br/wp-content/uploads/2012/01/3252a.jpg'
  },
  {
    id: 5,
    pergunta: 'Qual planeta tem os anéis mais visíveis?',
    opcoes: ['Júpiter', 'Urano', 'Netuno', 'Saturno'],
    respostaCerta: 3,
    imagem: 'https://services.meteored.com/img/article/terra-com-aneis-como-os-de-saturno-astronomos-argumentam-que-terra-ja-possuiu-aneis-1726748209480_1280.png'
  },
  {
    id: 6,
    pergunta: 'Qual é o menor planeta do Sistema Solar?',
    opcoes: ['Marte', 'Vênus', 'Mercúrio', 'Plutão'],
    respostaCerta: 2,
    imagem: 'https://s.rfi.fr/media/display/0a9af8fa-1656-11ea-974d-005056a99247/w:1024/p:16x9/mercury_earth_size_comparison.jpg'
  },
  {
    id: 7,
    pergunta: 'Qual planeta é conhecido como o "Planeta Azul"?',
    opcoes: ['Marte', 'Vênus', 'Terra', 'Netuno'],
    respostaCerta: 2,
    imagem: 'https://s2.glbimg.com/9qsld0QqbkS4vlbYgwaISENeQNA=/e.glbimg.com/og/ed/f/original/2019/02/21/neptune1.en.jpg'
  },
  {
    id: 8,
    pergunta: 'Qual é o planeta mais quente do Sistema Solar?',
    opcoes: ['Mercúrio', 'Vênus', 'Marte', 'Júpiter'],
    respostaCerta: 1,
    imagem: 'https://static.nationalgeographicbrasil.com/files/styles/image_3200/public/sistema-solar-nasa.jpg?w=1600'
  },
  {
    id: 9,
    pergunta: 'Quantos planetas existem no Sistema Solar?',
    opcoes: ['7', '8', '9', '10'],
    respostaCerta: 1,
    imagem: 'https://static.ndmais.com.br/2024/03/man-5723449-1280-800x560.jpg'
  },
  {
    id: 10,
    pergunta: 'Qual planeta tem a maior lua do Sistema Solar?',
    opcoes: ['Júpiter', 'Saturno', 'Urano', 'Netuno'],
    respostaCerta: 0,
    imagem: 'https://s2.glbimg.com/dhojlEWJrJNdwj_9LOIOJkW31AU=/s.glbimg.com/jo/g1/f/original/2015/08/03/lua-iss3.jpg'
  }
];

export default function AppQuiz() {
  const [telaAtual, setTelaAtual] = useState('inicio');
  const [perguntaAtual, setPerguntaAtual] = useState(0);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);
  const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);
  const [opcaoCerta, setOpcaoCerta] = useState(null);
  const [botoesBloqueados, setBotoesBloqueados] = useState(false);

  function iniciarJogo() {
    setPerguntaAtual(0);
    setPontuacao(0);
    setTelaAtual('quiz');
  }

  function voltarAoInicio() {
    setTelaAtual('inicio');
  }

  function responder(indiceClicado) {
    if (botoesBloqueados) return;
    
    const pergunta = QUIZ[perguntaAtual];
    const isCorrect = indiceClicado === pergunta.respostaCerta;
    
    setOpcaoSelecionada(indiceClicado);
    setOpcaoCerta(pergunta.respostaCerta);
    setBotoesBloqueados(true);
    
    setTimeout(() => {
      if (isCorrect) {
        setPontuacao(pontuacao + 1);
      }
      
      setCarregando(true);
      
      setTimeout(() => {
        if (perguntaAtual + 1 < QUIZ.length) {
          setPerguntaAtual(perguntaAtual + 1);
          setOpcaoSelecionada(null);
          setOpcaoCerta(null);
          setBotoesBloqueados(false);
        } else {
          setTelaAtual('resultado');
          setOpcaoSelecionada(null);
          setOpcaoCerta(null);
          setBotoesBloqueados(false);
        }
        setCarregando(false);
      }, 1000);
    }, 1000);
  }

  if (telaAtual === 'inicio') {
    return (
      <View style={styles.telaCentrada}>
        <Image
          source={{ uri: 'https://static.ndmais.com.br/2025/03/planeta-do-sistema-solar.jpg' }}
          style={styles.logoInicial}
        />
        <Text style={styles.tituloPrincipal}>Quiz do Sistema Solar</Text>
        <Text style={styles.subtituloInicio}>Teste seus conhecimentos sobre o Sistema Solar!</Text>
        <TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
          <Text style={styles.textoBotaoIniciar}>INICIAR JOGO</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (telaAtual === 'resultado') {
    return (
      <View style={styles.telaCentrada}>
        <Text style={styles.iconeGrande}>🚀</Text>
        <Text style={styles.titulo}>Fim de Jogo!</Text>
        <Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
        <TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (carregando) {
    return (
      <View style={styles.telaCentrada}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.textoCarregando}>Validando resposta...</Text>
      </View>
    );
  }

  const pergunta = QUIZ[perguntaAtual];
  return (
    <View style={styles.tela}>
      <View style={styles.cabecalho}>
        <Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
        <Text style={styles.pontos}>⭐ {pontuacao}</Text>
      </View>
      
      <View style={styles.cartaoPergunta}>
        <Image
          source={{ uri: pergunta.imagem }}
          style={styles.imagemPergunta}
          resizeMode="cover"
        />
        <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
      </View>
      
      <View style={styles.areaOpcoes}>
        {pergunta.opcoes.map((opcao, index) => {
          let corFundo = 'white';
          let corBorda = '#e2e8f0';
          
          if (botoesBloqueados || opcaoSelecionada !== null) {
            if (index === opcaoCerta) {
              corFundo = '#10b981';
              corBorda = '#10b981';
            } else if (index === opcaoSelecionada && index !== opcaoCerta) {
              corFundo = '#ef4444';
              corBorda = '#ef4444';
            }
          }
          
          return (
            <TouchableOpacity
              key={index}
              style={[
                styles.botaoOpcao,
                { backgroundColor: corFundo, borderColor: corBorda }
              ]}
              onPress={() => responder(index)}
              disabled={botoesBloqueados}
              activeOpacity={0.7}
            >
              <Text style={[
                styles.textoOpcao,
                (botoesBloqueados || opcaoSelecionada !== null) && styles.textoOpcaoBranco
              ]}>{opcao}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { 
    flex: 1, 
    backgroundColor: '#0f172a', 
    padding: 20, 
    paddingTop: 40 
  },
  telaCentrada: { 
    flex: 1, 
    backgroundColor: '#0f172a', 
    justifyContent: 'center', 
    alignItems: 'center',
    padding: 20 
  },
  logoInicial: { 
    width: 200, 
    height: 200, 
    marginBottom: 30,
    borderRadius: 20
  },
  tituloPrincipal: { 
    fontSize: 36, 
    fontWeight: '900', 
    color: '#f8fafc', 
    marginBottom: 10, 
    textAlign: 'center' 
  },
  subtituloInicio: { 
    fontSize: 16, 
    color: '#94a3b8', 
    marginBottom: 50, 
    textAlign: 'center',
    paddingHorizontal: 20 
  },
  botaoIniciar: { 
    backgroundColor: '#10b981', 
    paddingVertical: 20, 
    paddingHorizontal: 40,
    borderRadius: 20, 
    width: '100%', 
    maxWidth: 300, 
    shadowColor: '#10b981', 
    shadowOpacity: 0.4, 
    shadowRadius: 15, 
    elevation: 8, 
    alignItems: 'center' 
  },
  textoBotaoIniciar: { 
    color: 'white', 
    fontSize: 20, 
    fontWeight: '900', 
    letterSpacing: 1 
  },
  cabecalho: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 20, 
    paddingHorizontal: 10 
  },
  progresso: { 
    fontSize: 16, 
    fontWeight: '700', 
    color: '#94a3b8' 
  },
  pontos: { 
    fontSize: 16, 
    fontWeight: '800', 
    color: '#fbbf24' 
  },
  cartaoPergunta: { 
    backgroundColor: '#1e293b', 
    padding: 20, 
    borderRadius: 20, 
    marginBottom: 20, 
    shadowColor: '#0f172a', 
    shadowOpacity: 0.3, 
    shadowRadius: 15, 
    elevation: 5,
    alignItems: 'center'
  },
  imagemPergunta: {
    width: '100%',
    height: 200,
    borderRadius: 15,
    marginBottom: 20
  },
  textoPergunta: { 
    fontSize: 22, 
    fontWeight: '800', 
    color: '#f8fafc', 
    textAlign: 'center',
    lineHeight: 30 
  },
  areaOpcoes: { 
    flex: 1 
  },
  botaoOpcao: { 
    padding: 20, 
    borderRadius: 15, 
    marginBottom: 15,
    borderWidth: 2,
    borderColor: '#e2e8f0',
    backgroundColor: 'white'
  },
  textoOpcao: { 
    fontSize: 18, 
    color: '#334155', 
    fontWeight: '600', 
    textAlign: 'center' 
  },
  textoOpcaoBranco: {
    color: 'white'
  },
  iconeGrande: { 
    fontSize: 80, 
    marginBottom: 20 
  },
  titulo: { 
    fontSize: 32, 
    fontWeight: '900', 
    color: '#f8fafc', 
    marginBottom: 10 
  },
  subtitulo: { 
    fontSize: 18, 
    color: '#94a3b8', 
    marginBottom: 40 
  },
  botaoAcao: { 
    backgroundColor: '#3b82f6', 
    paddingVertical: 18, 
    paddingHorizontal: 40,
    borderRadius: 16, 
    width: '100%', 
    maxWidth: 300, 
    alignItems: 'center' 
  },
  textoBotaoAcao: { 
    color: 'white', 
    fontSize: 18, 
    fontWeight: '800' 
  },
  textoCarregando: { 
    marginTop: 20, 
    fontSize: 18, 
    fontWeight: '600', 
    color: '#3b82f6' 
  }
});